mt19937predictor module
=======================

.. automodule:: mt19937predictor
    :members:
    :undoc-members:
    :show-inheritance:

.. doctest::  mt19937predictor
